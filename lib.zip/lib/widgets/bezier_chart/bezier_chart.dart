library bezier_chart;

export 'bezier_chart_config.dart';
export 'bezier_chart_widget.dart';
export 'bezier_line.dart';

/// 曲线图表（修改版本：1.0.17+1） https://github.com/aeyrium/bezier-chart