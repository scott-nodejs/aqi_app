
import 'package:flutter/material.dart';

class HomeProvider extends ValueNotifier<int> {
  HomeProvider() : super(0);
}