
import 'package:fluro/fluro.dart';

abstract class IRouterProvider {
  
  void initRouter(FluroRouter router);
}